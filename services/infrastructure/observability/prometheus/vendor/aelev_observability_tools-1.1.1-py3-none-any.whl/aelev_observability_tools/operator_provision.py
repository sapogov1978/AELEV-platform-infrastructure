"""Explicitly provision only an owner's confidential operator identity."""

from __future__ import annotations

import logging
import os
from pathlib import Path
import ssl
import sys
from typing import Any

import httpx

from .operator import ROLE, Settings


def provision(prefix: str, root: Path, admin: Path) -> None:
    """Retain existing credentials and reject identities owned by anyone else."""
    cfg = Settings.environment(prefix)
    context = ssl.create_default_context(cafile=str(root / "identity-ca.crt"))
    with httpx.Client(
        base_url=cfg.backchannel,
        verify=context,
        timeout=cfg.timeout,
        follow_redirects=False,
        trust_env=False,
    ) as client:
        discovery = client.get(
            "/realms/" + cfg.realm + "/.well-known/openid-configuration"
        )
        discovery.raise_for_status()
        if discovery.json()["issuer"] != cfg.issuer:
            raise ValueError(
                "operator issuer differs from the identity provider's canonical origin"
            )
        token = client.post(
            "/realms/master/protocol/openid-connect/token",
            data={
                "client_id": "admin-cli",
                "grant_type": "password",
                "username": (admin / "admin-user").read_text().strip(),
                "password": (admin / "admin-password").read_text().strip(),
            },
        )
        token.raise_for_status()
        client.headers["Authorization"] = "Bearer " + token.json()["access_token"]
        base = "/admin/realms/" + cfg.realm

        def request(method: str, path: str, **kwargs: Any) -> Any:
            reply = client.request(method, base + path, **kwargs)
            reply.raise_for_status()
            return reply.json() if reply.content else None

        users = request(
            "GET", "/users", params={"username": cfg.operator_user, "exact": "true"}
        )
        if len(users) != 1 or not users[0].get("enabled"):
            raise ValueError("an existing enabled operator is required")
        matches = request("GET", "/clients", params={"clientId": cfg.client_id})
        if matches and (
            len(matches) != 1
            or matches[0].get("attributes", {}).get("aelev.owner") != prefix
        ):
            raise ValueError("foreign operator client")
        config = {
            "clientId": cfg.client_id,
            "protocol": "openid-connect",
            "enabled": True,
            "publicClient": False,
            "standardFlowEnabled": True,
            "implicitFlowEnabled": False,
            "directAccessGrantsEnabled": False,
            "serviceAccountsEnabled": False,
            "fullScopeAllowed": False,
            "redirectUris": [cfg.callback],
            "webOrigins": [cfg.public_url],
            "attributes": {"pkce.code.challenge.method": "S256", "aelev.owner": prefix},
            "protocolMappers": [
                {
                    "name": "operator-audience",
                    "protocol": "openid-connect",
                    "protocolMapper": "oidc-audience-mapper",
                    "config": {
                        "included.client.audience": cfg.client_id,
                        "access.token.claim": "true",
                        "introspection.token.claim": "true",
                    },
                }
            ],
        }
        if matches:
            path = "/clients/" + matches[0]["id"]
            request("PUT", path, json=config)
        else:
            request("POST", "/clients", json=config)
            matches = request("GET", "/clients", params={"clientId": cfg.client_id})
            path = "/clients/" + matches[0]["id"]
        role = client.get(base + path + "/roles/" + ROLE)
        if role.status_code == 404:
            request("POST", path + "/roles", json={"name": ROLE})
        else:
            role.raise_for_status()
        roles = [request("GET", path + "/roles/" + ROLE)]
        mapping = "/scope-mappings/clients/" + matches[0]["id"]
        request("POST", path + mapping, json=roles)
        request(
            "POST",
            "/users/" + users[0]["id"] + "/role-mappings/clients/" + matches[0]["id"],
            json=roles,
        )
        secret = request("GET", path + "/client-secret")["value"]
        destination = root / "client-secret"
        if destination.exists() and destination.read_text().strip() != secret:
            raise ValueError(
                "existing operator secret differs; explicit rotation required"
            )
        if not destination.exists():
            descriptor = os.open(
                destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o640
            )
            with os.fdopen(descriptor, "w") as stream:
                stream.write(secret)


if __name__ == "__main__":
    provision(
        sys.argv[1], Path("/run/secrets/operator"), Path("/run/secrets/status-admin")
    )
    logging.getLogger(__name__).warning('{"event":"operator_client_provisioned"}')
