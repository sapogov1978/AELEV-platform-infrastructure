"""Owner-contained read-only browser access, independent of technical mTLS."""

from __future__ import annotations

import asyncio
import base64
from dataclasses import dataclass
import hashlib
import json
import logging
import os
from pathlib import Path
import re
import secrets
import ssl
import threading
import time
from typing import Any
from urllib.parse import parse_qs, unquote, urlencode, urlsplit

import httpx
from fastapi import FastAPI, Request
from starlette.responses import RedirectResponse, Response
import uvicorn
import http.client
import socket

LOG = logging.getLogger(__name__)
ROLE = "operator-read"
READ_POSTS = {"/api/v1/query", "/api/v1/query_range", "/api/v1/format_query"}
MAX_REQUEST = 1024 * 1024
MAX_RESPONSE = 8 * 1024 * 1024
MAX_SESSIONS = 128


def origin(value: str, *, https: bool = True) -> str:
    """Require an unambiguous origin, never credentials or arbitrary paths."""
    parsed = urlsplit(value)
    if (
        parsed.scheme not in ({"https"} if https else {"http", "https"})
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.path not in {"", "/"}
        or parsed.query
        or parsed.fragment
        or re.search(r"[\s\\]", value)
        or parsed.port is None
    ):
        raise ValueError("operator origin requires a scheme, host and explicit port")
    return value.rstrip("/")


@dataclass(frozen=True)
class Settings:
    """Public settings belong to one deployment; secrets remain file inputs."""

    mode: str
    public_url: str
    bind: str
    upstream: str
    identity_url: str
    backchannel: str
    realm: str
    client_id: str
    operator_user: str
    timeout: float

    @classmethod
    def environment(cls, prefix: str) -> Settings:
        values = {
            key: os.environ[prefix + "OPERATOR_" + key]
            for key in (
                "MODE",
                "PUBLIC_URL",
                "BIND",
                "PORT",
                "UPSTREAM",
                "IDENTITY_URL",
                "BACKCHANNEL",
                "REALM",
                "CLIENT_ID",
                "USER",
                "TIMEOUT_SECONDS",
            )
        }
        return cls.from_values(values)

    @classmethod
    def from_values(cls, values: dict[str, str]) -> Settings:
        public = origin(values["PUBLIC_URL"], https=False)
        if str(urlsplit(public).port) != values["PORT"]:
            raise ValueError("operator URL port must match the published port")
        mode = values["MODE"]
        if mode not in {"local-test", "prod"}:
            raise ValueError("OPERATOR_MODE must be local-test or prod")
        if mode == "local-test":
            if (
                urlsplit(public).scheme != "http"
                or urlsplit(public).hostname not in {"localhost", "127.0.0.1"}
                or values["BIND"] != "127.0.0.1"
            ):
                raise ValueError("local-test requires exact HTTP loopback and bind")
        elif urlsplit(public).scheme != "https":
            raise ValueError("prod requires HTTPS")
        for key in ("REALM", "CLIENT_ID", "USER"):
            if not re.fullmatch(r"[a-zA-Z0-9_.@-]{1,120}", values[key]):
                raise ValueError(f"invalid operator setting: {key}")
        timeout = float(values["TIMEOUT_SECONDS"])
        if not 1 <= timeout <= 30:
            raise ValueError("operator timeout must be 1..30 seconds")
        return cls(
            mode,
            public,
            values["BIND"],
            origin(values["UPSTREAM"]),
            origin(values["IDENTITY_URL"]),
            origin(values["BACKCHANNEL"]),
            values["REALM"],
            values["CLIENT_ID"],
            values["USER"],
            timeout,
        )

    @property
    def issuer(self) -> str:
        return self.identity_url + "/realms/" + self.realm

    @property
    def callback(self) -> str:
        return self.public_url + "/operator/callback"

    @property
    def cookie(self) -> str:
        return (
            "aelev_operator_" + hashlib.sha256(self.client_id.encode()).hexdigest()[:12]
        )


def authorized(claims: dict[str, Any], cfg: Settings) -> bool:
    """Validate trusted introspection, not an unverified decoded JWT."""
    audience = claims.get("aud", [])
    if isinstance(audience, str):
        audience = [audience]
    roles = claims.get("resource_access", {}).get(cfg.client_id, {}).get("roles", [])
    return (
        claims.get("active") is True
        and claims.get("iss") == cfg.issuer
        and claims.get("azp") == cfg.client_id
        and isinstance(audience, list)
        and cfg.client_id in audience
        and isinstance(claims.get("exp"), (int, float))
        and claims["exp"] > time.time()
        and bool(claims.get("sub"))
        and isinstance(roles, list)
        and ROLE in roles
    )


def safe_path(path: str) -> bool:
    """Disallow absolute URLs and path aliases of restricted operations."""
    decoded = unquote(urlsplit(path).path)
    return (
        decoded.startswith("/")
        and not decoded.startswith("//")
        and not re.search(r"[\s\\]", decoded)
        and not any(part in {".", ".."} for part in decoded.split("/"))
        and "%" not in decoded
    )


def create_app(cfg: Settings, secret_root: Path, tls_root: Path) -> FastAPI:
    """Keep tokens only in bounded, short-lived process memory."""
    identity_tls = ssl.create_default_context(
        cafile=str(secret_root / "identity-ca.crt")
    )
    native_tls = ssl.create_default_context(cafile=str(tls_root / "ca.crt"))
    native_tls.load_cert_chain(tls_root / "client.crt", tls_root / "client.key")
    client_secret = (secret_root / "client-secret").read_text().strip()
    if not client_secret:
        raise ValueError("operator client secret is required")
    pending: dict[str, tuple[str, str, float]] = {}
    sessions: dict[str, tuple[str, float]] = {}
    app = FastAPI(openapi_url=None, docs_url=None, redoc_url=None)
    gate = asyncio.Semaphore(8)

    async def identity(path: str, data: dict[str, str]) -> dict[str, Any]:
        async with httpx.AsyncClient(
            verify=identity_tls,
            timeout=cfg.timeout,
            trust_env=False,
            follow_redirects=False,
        ) as client:
            reply = await client.post(
                cfg.backchannel
                + "/realms/"
                + cfg.realm
                + "/protocol/openid-connect/"
                + path,
                data=data,
                auth=(cfg.client_id, client_secret),
            )
            reply.raise_for_status()
            decoded: dict[str, Any] = reply.json()
            return decoded

    def cookie(response: Response, name: str, value: str, age: int) -> None:
        response.set_cookie(
            name,
            value,
            max_age=age,
            httponly=True,
            samesite="lax",
            secure=cfg.mode == "prod",
            path="/",
        )

    async def handle(request: Request) -> Response:
        if request.headers.get("host") != urlsplit(cfg.public_url).netloc:
            return Response("Unexpected host", status_code=400)
        path = request.url.path
        if not safe_path(path):
            return Response("Invalid path", status_code=400)
        now = time.time()
        for key, pending_flow in list(pending.items()):
            if pending_flow[2] <= now:
                pending.pop(key, None)
        for key, session_data in list(sessions.items()):
            if session_data[1] <= now:
                sessions.pop(key, None)
        if path == "/operator/health" and request.method == "GET":
            return Response("ready")
        if path == "/operator/login" and request.method == "GET":
            if len(pending) >= MAX_SESSIONS:
                return Response("Login capacity reached", status_code=503)
            state, verifier, proof = (secrets.token_urlsafe(32) for _ in range(3))
            pending[state] = (verifier, proof, now + 120)
            challenge = (
                base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
                .decode()
                .rstrip("=")
            )
            response = RedirectResponse(
                cfg.issuer
                + "/protocol/openid-connect/auth?"
                + urlencode(
                    {
                        "client_id": cfg.client_id,
                        "redirect_uri": cfg.callback,
                        "response_type": "code",
                        "scope": "openid",
                        "state": state,
                        "code_challenge": challenge,
                        "code_challenge_method": "S256",
                    }
                ),
                status_code=302,
            )
            cookie(response, cfg.cookie + "_login", proof, 120)
            return response
        if path == "/operator/callback" and request.method == "GET":
            query = parse_qs(request.url.query)
            states, code = query.get("state", []), query.get("code", [])
            if len(states) != 1 or len(code) != 1:
                return Response("Invalid login response", status_code=400)
            flow = pending.pop(states[0], None)
            if not flow or not secrets.compare_digest(
                flow[1], request.cookies.get(cfg.cookie + "_login", "")
            ):
                return Response("Login state mismatch", status_code=400)
            token = await identity(
                "token",
                {
                    "grant_type": "authorization_code",
                    "code": code[0],
                    "redirect_uri": cfg.callback,
                    "code_verifier": flow[0],
                },
            )
            access = token["access_token"]
            claims = await identity("token/introspect", {"token": access})
            if not authorized(claims, cfg):
                return Response("Operator permission required", status_code=403)
            if len(sessions) >= MAX_SESSIONS:
                return Response("Session capacity reached", status_code=503)
            session_id = secrets.token_urlsafe(32)
            sessions[session_id] = (access, min(claims["exp"], now + 900))
            response = RedirectResponse("/", status_code=302)
            cookie(response, cfg.cookie, session_id, 900)
            response.delete_cookie(cfg.cookie + "_login")
            return response
        if request.method not in {"GET", "HEAD"}:
            if request.method != "POST" or path not in READ_POSTS:
                return Response("Read-only interface", status_code=405)
            if request.headers.get("origin") != cfg.public_url:
                return Response("Unexpected origin", status_code=403)
        session = sessions.get(request.cookies.get(cfg.cookie, ""))
        if not session:
            if "text/html" in request.headers.get("accept", ""):
                return RedirectResponse("/operator/login", status_code=302)
            return Response("Login required", status_code=401)
        claims = await identity("token/introspect", {"token": session[0]})
        if not authorized(claims, cfg):
            return Response("Operator permission required", status_code=403)
        body = bytearray()
        async for chunk in request.stream():
            body.extend(chunk)
            if len(body) > MAX_REQUEST:
                return Response("Request too large", status_code=413)
        target = cfg.upstream + path
        if request.url.query:
            target += "?" + request.url.query
        headers = {
            key: value
            for key, value in request.headers.items()
            if key.lower() in {"accept", "accept-encoding", "content-type"}
        }
        async with httpx.AsyncClient(
            verify=native_tls,
            timeout=cfg.timeout,
            trust_env=False,
            follow_redirects=False,
        ) as client:
            async with client.stream(
                request.method, target, content=bytes(body), headers=headers
            ) as reply:
                payload = bytearray()
                async for chunk in reply.aiter_bytes():
                    payload.extend(chunk)
                    if len(payload) > MAX_RESPONSE:
                        return Response("Response too large", status_code=502)
                output = {
                    key: value
                    for key, value in reply.headers.items()
                    if key.lower() in {"content-type", "content-disposition"}
                }
                if "location" in reply.headers:
                    location = reply.headers["location"]
                    if not location.startswith("/") or location.startswith("//"):
                        return Response("Unexpected redirect", status_code=502)
                    output["location"] = location
                return Response(
                    bytes(payload), status_code=reply.status_code, headers=output
                )

    @app.middleware("http")
    async def boundary(request: Request, call_next: Any) -> Response:
        del call_next
        async with gate:
            try:
                async with asyncio.timeout(cfg.timeout * 2):
                    response = await handle(request)
            except (httpx.HTTPError, OSError, ValueError, KeyError, TimeoutError):
                LOG.warning(json.dumps({"event": "operator_dependency_unavailable"}))
                response = Response("Secure dependency unavailable", status_code=503)
        response.headers["Cache-Control"] = "no-store"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        return response

    return app


def main() -> None:
    """Run one owner's adapter; production never falls back to HTTP."""
    import sys

    cfg = Settings.environment(sys.argv[1])
    root = Path("/run/secrets/operator")
    native = Path("/run/secrets/observability")
    app = create_app(cfg, root, native)
    technical = FastAPI(openapi_url=None, docs_url=None, redoc_url=None)

    @technical.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ready"}

    def control() -> None:
        uvicorn.run(
            technical,
            host="0.0.0.0",
            port=9443,
            access_log=False,
            proxy_headers=False,
            ssl_certfile=str(native / "server.crt"),
            ssl_keyfile=str(native / "server.key"),
            ssl_ca_certs=str(native / "ca.crt"),
            ssl_cert_reqs=ssl.CERT_REQUIRED,
        )

    # This private readiness listener always uses mTLS, including local-test.
    thread = threading.Thread(target=control, daemon=True)
    thread.start()
    kwargs: dict[str, Any] = {}
    if cfg.mode == "prod":
        kwargs = {
            "ssl_certfile": str(native / "server.crt"),
            "ssl_keyfile": str(native / "server.key"),
            "ssl_version": ssl.PROTOCOL_TLS_SERVER,
        }
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8080,
        access_log=False,
        proxy_headers=False,
        limit_concurrency=16,
        timeout_keep_alive=5,
        **kwargs,
    )


def probe(cfg: Settings, host: str, context: ssl.SSLContext) -> int:
    """Connect to the own adapter and verify its public certificate SAN."""
    connection = http.client.HTTPConnection(host, 9443, timeout=cfg.timeout)
    raw = socket.create_connection((host, 9443), timeout=cfg.timeout)
    try:
        connection.sock = context.wrap_socket(
            raw,
            server_hostname=urlsplit(cfg.public_url).hostname,
        )
        connection.request("GET", "/health")
        return connection.getresponse().status
    finally:
        raw.close()
        connection.close()


if __name__ == "__main__":
    main()
