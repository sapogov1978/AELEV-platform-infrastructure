"""Read-only browser checks, invoked by each owner's own test entry point."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import importlib
import json
from pathlib import Path
import ssl
import socket
import subprocess
import time
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import urlopen

from . import read_env


def run(root: Path) -> int:
    """Use the actual owner and existing IdP; create no test service or identity."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--operator-password-file", required=True, type=Path)
    parser.add_argument("--chrome", required=True)
    parser.add_argument("--shell-url", default="https://127.0.0.1:18082")
    args = parser.parse_args()
    spec = json.loads((root / "deployment.json").read_text())
    env = read_env(root / ".env", spec["prefix"])
    checks: list[str] = []
    failure = ""
    stage = "native-mtls"
    public = env["OPERATOR_PUBLIC_URL"]
    native = root / env["SECRET_ROOT"]
    health = (
        "https://"
        + env["PUBLIC_HOST"]
        + ":"
        + env["PORT"]
        + urlsplit(env["UI_HEALTH_URL"]).path
    )
    context = ssl.create_default_context(cafile=str(native / "ca.crt"))
    try:
        try:
            with urlopen(health, context=context, timeout=10):
                raise AssertionError(
                    "native endpoint accepted a certificate-less client"
                )
        except (URLError, ssl.SSLError, OSError):
            pass
        context.load_cert_chain(native / "client.crt", native / "client.key")
        with urlopen(health, context=context, timeout=10) as response:
            assert response.status == 200
        checks.append(
            "Нативный HTTPS требует клиентский сертификат; собственная mTLS readiness возвращает 200."
        )
        playwright = importlib.import_module("playwright.sync_api")
        with playwright.sync_playwright() as runtime:
            browser = runtime.chromium.launch(
                executable_path=args.chrome, headless=True
            )
            # The existing local IdP/UI use an explicitly local test PKI; this
            # does not install trust into macOS or disable server-side TLS.
            local_hosts = {"127.0.0.1", "localhost", "::1"}
            local_pki = all(
                urlsplit(url).hostname in local_hosts
                for url in (public, env["OPERATOR_IDENTITY_URL"], args.shell_url)
            )
            page = browser.new_page(ignore_https_errors=local_pki)
            errors: list[str] = []
            page.on("pageerror", lambda error: errors.append(type(error).__name__))
            stage = "operator-login"
            page.goto(public)
            page.wait_for_selector("#kc-login")
            page.locator("#username").fill(env["OPERATOR_USER"])
            page.locator("#password").fill(
                args.operator_password_file.read_text().strip()
            )
            page.locator("#kc-login").click(no_wait_after=True)
            page.wait_for_url(
                public + "/**", timeout=60000, wait_until="domcontentloaded"
            )
            stage = "operator-page"
            assert page.locator("body").inner_text().strip() not in {
                "Login required",
                "Operator permission required",
                "Secure dependency unavailable",
            }
            if spec["role"] == "prometheus":
                page.get_by_role("button", name="Execute", exact=True).wait_for(
                    timeout=30000
                )
                assert "Prometheus" in page.title()
                result = page.evaluate(
                    "async () => (await fetch('/api/v1/query?query=up')).json()"
                )
                assert result["status"] == "success"
            else:
                assert "Blackbox" in page.locator("body").inner_text()
            assert not errors, "browser script errors"
            checks.append(
                "Настоящий UI открывается после собственного OIDC/PKCE без клиентского сертификата браузера; чтение работает."
            )
            for path in (
                "/-/reload",
                "/api/v1/write",
                "/api/v1/admin/tsdb/delete_series",
            ):
                code = page.evaluate(
                    "async path => (await fetch(path, {method: 'POST'})).status", path
                )
                assert code == 405
            checks.append(
                "Запись телеметрии, reload и административное удаление запрещены с HTTP 405."
            )
            stage = "shell"
            with page.expect_response(
                lambda reply: urlsplit(reply.url).path == "/api/modules"
                and reply.status == 200,
                timeout=60000,
            ) as received:
                page.goto(args.shell_url)
                if page.locator("#kc-login").count():
                    page.locator("#username").fill(env["OPERATOR_USER"])
                    page.locator("#password").fill(
                        args.operator_password_file.read_text().strip()
                    )
                    page.locator("#kc-login").click(no_wait_after=True)
            modules: dict[str, Any] = received.value.json()
            module = next(
                m for m in modules["modules"] if m["module_id"] == env["UI_MODULE_ID"]
            )
            assert module["ui_url"] == public and module["revision"] == int(
                env["UI_REVISION"]
            )
            assert module["status"]["state"] == "ONLINE"
            assert any(
                c["id"] == "operator" and c["state"] == "ONLINE"
                for c in module["status"]["components"]
            )
            checks.append(
                "Оболочка получила новую собственную ссылку и состояние operator=ONLINE в большей ревизии; UUID сохранён."
            )
            browser.close()
    except Exception as error:
        # Do not persist callback URLs, tokens, credentials or request bodies.
        failure = type(error).__name__
    report = [
        "# Проверка операторского входа " + spec["role"],
        "",
        "Время UTC: " + datetime.now(timezone.utc).isoformat(),
        "",
        "Итог: " + ("FAIL" if failure else "PASS") + ".",
        "",
        *["- PASS: " + check for check in checks],
        "",
        "Режим: " + env["OPERATOR_MODE"] + ". Адрес: " + public + ".",
        "",
        "Использованы реальные ранее запущенные продукт, Keycloak и оболочка. Тест не создаёт контейнеры, тома, данные или identities; браузерный контекст удаляется. Локальная PKI браузерного теста не устанавливается в macOS. WAN, production PKI, MFA и нагрузка здесь не проверены.",
        "",
    ]
    if failure:
        report += ["Ошибка: " + failure + "; этап: " + stage + ".", ""]
    (root / "test/operator-access-result.md").write_text("\n".join(report))
    print(
        json.dumps(
            {
                "role": spec["role"],
                "result": "FAIL" if failure else "PASS",
                "checks": len(checks),
                "error_type": failure,
                "stage": stage,
            }
        )
    )
    return int(bool(failure))


def tls_modes(root: Path) -> int:
    """Exercise the same canonical operator role in prod without new identities."""
    spec = json.loads((root / "deployment.json").read_text())
    env = read_env(root / ".env", spec["prefix"])
    prefix = spec["prefix"] + "OPERATOR_"
    with socket.socket() as reserve:
        reserve.bind(("127.0.0.1", 0))
        port = reserve.getsockname()[1]
    name = "aelev-operator-tls-check-" + str(port)
    container = ""
    failure = ""
    checks: list[str] = []
    try:
        started = subprocess.run(
            [
                "docker",
                "compose",
                "--env-file",
                ".env",
                "run",
                "-d",
                "--rm",
                "--no-deps",
                "--name",
                name,
                "-p",
                f"127.0.0.1:{port}:8080",
                "-e",
                prefix + "MODE=prod",
                "-e",
                prefix + "PUBLIC_URL=https://127.0.0.1:" + str(port),
                "-e",
                prefix + "PORT=" + str(port),
                spec["role"] + "-operator",
            ],
            cwd=root,
            capture_output=True,
            text=True,
            check=True,
        )
        container = started.stdout.strip()
        assert len(container) == 64 and all(c in "0123456789abcdef" for c in container)
        context = ssl.create_default_context(
            cafile=str(root / env["OPERATOR_TLS_ROOT"] / "ca.crt")
        )
        for attempt in range(30):
            try:
                with urlopen(f"https://127.0.0.1:{port}/", context=context, timeout=2):
                    raise AssertionError("anonymous production access")
            except HTTPError as error:
                assert error.code == 401
                break
            except (OSError, URLError):
                if attempt == 29:
                    raise
                time.sleep(0.25)
        checks.append(
            "Тот же собственный Compose/образ в prod принимает HTTPS с проверкой CA/SAN без сертификата клиента браузера; без авторизации возвращает 401."
        )
        try:
            with urlopen(f"http://127.0.0.1:{port}/operator/health", timeout=2):
                raise AssertionError("prod fell back to HTTP")
        except (OSError, URLError):
            pass
        checks.append(
            "Незашифрованный HTTP на prod-порту отвергается; перехода к local-test нет."
        )
    except Exception as error:
        failure = type(error).__name__
    finally:
        if container:
            subprocess.run(
                ["docker", "stop", container],
                capture_output=True,
                text=True,
                check=True,
            )
            for _ in range(40):
                remaining = subprocess.run(
                    [
                        "docker",
                        "ps",
                        "-a",
                        "--filter",
                        "id=" + container,
                        "--format",
                        "{{.ID}}",
                    ],
                    capture_output=True,
                    text=True,
                    check=True,
                )
                if not remaining.stdout.strip():
                    break
                time.sleep(0.1)
            if remaining.stdout.strip():
                failure = "CleanupIncomplete"
    report = [
        "# Проверка TLS режима prod: " + spec["role"],
        "",
        "Время UTC: " + datetime.now(timezone.utc).isoformat(),
        "",
        "Итог: " + ("FAIL" if failure else "PASS") + ".",
        "",
        *["- PASS: " + check for check in checks],
        "",
        "Использован канонический Compose владельца с переопределением только режима/порта в одноразовом run --rm. Тестовый контейнер остановлен и удалён; тома, identities, env и рабочие процессы не менялись. Использована существующая локальная PKI: продукционное доверие/WAN и полный OIDC-вход на удалённом HTTPS здесь не доказаны; настоящий OIDC/PKCE отдельно проверен в local-test.",
        "",
    ]
    if failure:
        report += ["Ошибка: " + failure + ".", ""]
    (root / "test/operator-tls-result.md").write_text("\n".join(report))
    print(
        json.dumps(
            {
                "role": spec["role"],
                "result": "FAIL" if failure else "PASS",
                "checks": len(checks),
                "cleanup": "FAIL" if failure == "CleanupIncomplete" else "PASS",
                "error_type": failure,
            }
        )
    )
    return int(bool(failure))
