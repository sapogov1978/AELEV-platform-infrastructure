"""Minimal privileged initialization, with no network or credentials."""

import argparse
from pathlib import Path

from . import initialize

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--owner", required=True)
parser.add_argument("--role", required=True)
parser.add_argument("--uid", type=int, required=True)
parser.add_argument("--directory", type=Path, default=Path("/data"))
arguments = parser.parse_args()
initialize(arguments.directory, arguments.owner, arguments.role, arguments.uid)
