"""Dependency-free probe of both event loops in one operator process."""

from __future__ import annotations

import json
import math
import os
from pathlib import Path
import stat
import time

ROOT = Path("/tmp/aelev-operator-health")
ROLES = ("browser", "technical")
MAX_AGE = 15.0


def publish(role: str, root: Path = ROOT) -> None:
    """Replace an ephemeral heartbeat from the observed event loop itself."""
    if role not in ROLES:
        raise ValueError("unknown operator event loop")
    root.mkdir(mode=0o700, exist_ok=True)
    if root.is_symlink() or root.stat().st_uid != os.getuid():
        raise ValueError("foreign heartbeat directory")
    temporary = root / (role + ".new")
    descriptor = os.open(
        temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600
    )
    with os.fdopen(descriptor, "w") as stream:
        json.dump({"pid": os.getpid(), "at": time.monotonic()}, stream)
    temporary.replace(root / (role + ".json"))


def check(root: Path = ROOT) -> bool:
    """Read only local signals; never import the application or contact TLS/DB."""
    try:
        directory = root.lstat()
        if not stat.S_ISDIR(directory.st_mode) or directory.st_uid != os.getuid():
            return False
        pids: set[int] = set()
        now = time.monotonic()
        for role in ROLES:
            descriptor = os.open(root / (role + ".json"), os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(descriptor) as stream:
                info = os.fstat(stream.fileno())
                if (
                    not stat.S_ISREG(info.st_mode)
                    or info.st_uid != os.getuid()
                    or info.st_size > 512
                ):
                    return False
                value = json.loads(stream.read(513))
            if not isinstance(value, dict) or set(value) != {"pid", "at"}:
                return False
            pid, stamp = value["pid"], value["at"]
            if (
                type(pid) is not int
                or pid < 1
                or type(stamp) not in (int, float)
                or not math.isfinite(stamp)
                or not 0 <= now - stamp <= MAX_AGE
            ):
                return False
            os.kill(pid, 0)
            pids.add(pid)
        return len(pids) == 1
    except (OSError, ValueError, TypeError, OverflowError):
        return False


if __name__ == "__main__":
    raise SystemExit(0 if check() else 1)
