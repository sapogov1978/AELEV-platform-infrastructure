# Проверка общей инфраструктурной оркестрации

Начало: 2026-11-08T14:36:13.376910+00:00. Итог: PASS.

Использованы реальные поставки и собственные env, удостоверения и тома. Поддельных Kafka, IdP, API или издателей нет. Данные существовавших до запуска томов не удалялись; технические отчёты и реальные задачи владельцев обновлялись штатно.

Механизм ограждения берётся из собственного env PostgreSQL, тест его не отключает. Повторное использование существующих данных: False. WAN, аппаратное ограждение, продукционная PKI, нагрузка и независимое резервное восстановление не проверялись.

| Проверка | Результат | Подробность |
|---|---|---|
| Каноническая композиция, один Kafka и явно выбранное ограждение PostgreSQL | PASS |  |
| Самостоятельные и оркестрируемые роли владельцев полностью совпадают | PASS |  |
| Исходные ресурсы учтены; существующих писателей общих томов нет | PASS |  |
| Kafka самостоятельно healthy: ни одна роль переводчика не запущена | PASS |  |
| Настоящая инициализация собственного тома: delivery-configuration-init — exit 0 | PASS |  |
| Настоящая инициализация собственного тома: grafana-configuration-init — exit 0 | PASS |  |
| Настоящая инициализация собственного тома: loki-configuration-init — exit 0 | PASS |  |
| Настоящая инициализация собственного тома: otel-collector-configuration-init — exit 0 | PASS |  |
| Настоящая инициализация собственного тома: prometheus-configuration-init — exit 0 | PASS |  |
| Настоящая инициализация собственного тома: tempo-configuration-init — exit 0 | PASS |  |
| Настоящие Keycloak, его БД, TLS и импорт собственного realm | PASS |  |
| Реальная задача владельца: platform-ui-configuration-init — exit 0 | PASS |  |
| Реальная задача владельца: grafana-oidc-provision — exit 0 | PASS |  |
| Реальная задача владельца: blackbox-exporter-operator-provision — exit 0 | PASS |  |
| Реальная задача владельца: prometheus-operator-provision — exit 0 | PASS |  |
| Реальная задача владельца: translator-api-provision — exit 0 | PASS |  |
| Реальная задача владельца: blackbox-exporter-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: delivery-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: grafana-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: kafka-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: keycloak-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: loki-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: minio-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: otel-collector-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: platform-ui-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: postgresql-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: prometheus-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: public-egress-gateway-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: tempo-status-provision — exit 0 | PASS |  |
| Реальная задача владельца: translator-service-status-provision — exit 0 | PASS |  |
| Реальная проверка/настройка MinIO site replication: exit 0 | PASS |  |
| Общий старт: healthcheck, автоматические миграции и topics готовы | PASS | 51 ролей; 49 healthcheck; остальные постоянные роли RUNNING и далее проверяются владельцами через UI |
| Настоящие OIDC, API и DOM: все собственные строки ONLINE | PASS | 14 строк |
| Общая остановка: ни один контейнер группы не работает | PASS |  |
| Повторный старт: прежние контейнеры, identities и возрастающие последовательности | PASS |  |
| Общее down сняло контейнеры; постоянные тома сохранены | PASS |  |
| Down/up: новые контейнеры работают с прежними данными и identities | PASS |  |
| Очистка: созданное снято, все исходные ресурсы и чужие состояния сохранены | PASS |  |

| Название владельца | Компоненты | Последовательность |
|---|---|---|
| Интерфейс платформы | 3 ONLINE | 8 |
| Панели наблюдения и уведомления | 2 ONLINE | 8 |
| Хранилище структурированных данных | 9 ONLINE | 8 |
| Контролируемый доступ к публичной сети | 2 ONLINE | 9 |
| Доставка телеметрии | 2 ONLINE | 8 |
| Обработка телеметрии | 2 ONLINE | 8 |
| Хранение и поиск трасс | 2 ONLINE | 9 |
| Хранилище метрик | 3 ONLINE | 7 |
| Перевод текстов | 7 ONLINE | 8 |
| Межсервисное взаимодействие | 2 ONLINE | 8 |
| Проверка доступности | 3 ONLINE | 7 |
| Хранилище артефактов | 9 ONLINE | 8 |
| Хранение и поиск журналов | 2 ONLINE | 8 |
| Идентификация и доступ | 3 ONLINE | 8 |

Снимок страницы состояния: `root-lifecycle.png`.

Сверены сохранённые исходные ресурсы: containers: 0, networks: 3, volumes: 0, images: 41. Созданных контейнеров, сетей и томов теста не осталось; рабочие env, секреты и образы сохранены.
