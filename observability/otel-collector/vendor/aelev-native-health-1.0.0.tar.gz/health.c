/* Local, bounded mTLS HTTP liveness; never inspect a dependency or response body. */
#define _POSIX_C_SOURCE 200809L
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netinet/in.h>
#include <openssl/ssl.h>
#include <openssl/x509v3.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

static void deadline(int number) {
    (void)number;
    _exit(124);
}

static int no_password(char *buffer, int size, int write, void *argument) {
    (void)buffer;
    (void)size;
    (void)write;
    (void)argument;
    return 0;
}

static int path(char *result, size_t size, const char *root, const char *name) {
    int length = snprintf(result, size, "%s/%s", root, name);
    return length > 0 && (size_t)length < size;
}

int main(int argc, char **argv) {
    if (argc != 4 || !argv[1][0] || !argv[2][0] || argv[3][0] != '/') return 2;
    for (const char *p = argv[1]; *p; ++p)
        if (!isdigit((unsigned char)*p)) return 2;
    errno = 0;
    char *end = NULL;
    long port = strtol(argv[1], &end, 10);
    if (errno || *end || port < 1 || port > 65535 || strlen(argv[2]) > 253) return 2;
    for (const char *p = argv[2]; *p; ++p)
        if (!isalnum((unsigned char)*p) && *p != '.' && *p != '-') return 2;
    char ca[512], certificate[512], key[512];
    if (!path(ca, sizeof(ca), argv[3], "ca.crt") ||
        !path(certificate, sizeof(certificate), argv[3], "client.crt") ||
        !path(key, sizeof(key), argv[3], "client.key")) return 2;

    struct sigaction action = {0};
    action.sa_handler = deadline;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGALRM, &action, NULL) != 0) return 3;
    signal(SIGPIPE, SIG_IGN);
    alarm(3);
    int result = 3;
    int fd = -1;
    SSL_CTX *ctx = SSL_CTX_new(TLS_client_method());
    SSL *tls = NULL;
    if (!ctx || !SSL_CTX_set_min_proto_version(ctx, TLS1_2_VERSION)) goto done;
    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);
    SSL_CTX_set_default_passwd_cb(ctx, no_password);
    if (SSL_CTX_load_verify_locations(ctx, ca, NULL) != 1 ||
        SSL_CTX_use_certificate_chain_file(ctx, certificate) != 1 ||
        SSL_CTX_use_PrivateKey_file(ctx, key, SSL_FILETYPE_PEM) != 1 ||
        SSL_CTX_check_private_key(ctx) != 1) goto done;
    tls = SSL_new(ctx);
    if (!tls) goto done;
    unsigned char ip[sizeof(struct in_addr)];
    if (inet_pton(AF_INET, argv[2], ip) == 1) {
        if (X509_VERIFY_PARAM_set1_ip_asc(SSL_get0_param(tls), argv[2]) != 1) goto done;
    } else {
        SSL_set_hostflags(tls, X509_CHECK_FLAG_NEVER_CHECK_SUBJECT);
        if (SSL_set1_host(tls, argv[2]) != 1 ||
            SSL_set_tlsext_host_name(tls, argv[2]) != 1) goto done;
    }
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) goto done;
    const struct timeval timeout = {.tv_sec = 3, .tv_usec = 0};
    if (setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)) != 0 ||
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout)) != 0) goto done;
    struct sockaddr_in address = {0};
    address.sin_family = AF_INET;
    address.sin_port = htons((unsigned short)port);
    address.sin_addr.s_addr = htonl(0x7f000001u);
    if (connect(fd, (struct sockaddr *)&address, sizeof(address)) != 0 ||
        SSL_set_fd(tls, fd) != 1 || SSL_connect(tls) != 1 ||
        SSL_get_verify_result(tls) != X509_V_OK) goto done;
    char request[512];
    int length = snprintf(request, sizeof(request),
        "HEAD /__aelev_liveness__ HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n\r\n", argv[2]);
    if (length < 1 || (size_t)length >= sizeof(request) ||
        SSL_write(tls, request, length) != length) goto done;
    char line[128];
    size_t used = 0;
    while (used < sizeof(line) - 1) {
        if (SSL_read(tls, line + used, 1) != 1) goto done;
        if (line[used++] == '\n') break;
    }
    line[used] = '\0';
    if (used < 14 || used == sizeof(line) - 1 || line[used - 1] != '\n' ||
        (strncmp(line, "HTTP/1.1 ", 9) != 0 && strncmp(line, "HTTP/1.0 ", 9) != 0) ||
        line[9] < '2' || line[9] > '5' ||
        !isdigit((unsigned char)line[10]) || !isdigit((unsigned char)line[11]) ||
        line[12] != ' ') goto done;
    /* Any final HTTP status proves the local dispatcher is alive. No redirect is followed. */
    result = 0;
done:
    SSL_free(tls);
    SSL_CTX_free(ctx);
    if (fd >= 0) close(fd);
    alarm(0);
    return result;
}
