"""Prepare a single deployment from its owner-local descriptor and templates."""

from __future__ import annotations

import argparse
import ipaddress
import json
import logging
import os
import re
import secrets
import shutil
import subprocess
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

LOG = logging.getLogger(__name__)


def read_env(path: Path, prefix: str) -> dict[str, str]:
    """Read required, uniquely named public settings without reading secrets."""
    result: dict[str, str] = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        key, separator, value = line.partition("=")
        short = key.removeprefix(prefix)
        if not separator or not key.startswith(prefix) or short in result:
            raise ValueError(f"invalid or duplicate setting: {key}")
        result[short] = value
    return result


def validate(
    env: dict[str, str], expected: dict[str, str], spec: dict[str, Any]
) -> None:
    """Fail closed on missing settings, invalid addresses and unsafe email setup."""
    if set(env) != set(expected):
        raise ValueError("env keys must match .env.example exactly")
    if "OPERATOR_MODE" in env:
        from .operator import Settings

        Settings.from_values(
            {
                key.removeprefix("OPERATOR_"): value
                for key, value in env.items()
                if key.startswith("OPERATOR_")
            }
        )
    if "UI_REVISION" in env and not 1 <= int(env["UI_REVISION"]) <= 9223372036854775807:
        raise ValueError("invalid owner description revision")
    for key, value in env.items():
        if not value and key not in spec.get("optional", []):
            raise ValueError(f"missing setting: {key}")
    if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9.-]*", env["PUBLIC_HOST"]):
        raise ValueError("PUBLIC_HOST must be a DNS name or IPv4 address")
    bind = ipaddress.ip_address(env["BIND"])
    if bind.version != 4:
        raise ValueError("BIND currently requires IPv4")
    ports = [int(env[key]) for key in spec["ports"]]
    if len(set(ports)) != len(ports) or any(not 1 <= p <= 65535 for p in ports):
        raise ValueError("ports must be valid and distinct")
    for key in spec.get("integers", []):
        if int(env[key]) < 1:
            raise ValueError(f"invalid integer: {key}")
    if int(env["SECRET_GID"]) < 0:
        raise ValueError("invalid integer: SECRET_GID")
    for key in spec.get("durations", []):
        if not re.fullmatch(r"[1-9][0-9]*[smhdw]", env[key]):
            raise ValueError(f"invalid duration: {key}")
    for key in spec.get("https", []):
        url = urlsplit(env[key])
        if (
            url.scheme != "https"
            or not url.hostname
            or url.username
            or url.password
            or url.fragment
        ):
            raise ValueError(f"expected a credential-free HTTPS endpoint: {key}")
    if (
        "CAPACITY_BYTES" in env
        and int(env["CAPACITY_BYTES"]) <= int(env["REQUEST_BYTES"]) + 1024
    ):
        raise ValueError("delivery capacity must exceed one bounded request")
    if "SMTP_ENABLED" in env:
        if env["SMTP_ENABLED"] not in {"true", "false"}:
            raise ValueError("SMTP_ENABLED must be true or false")
        if env["SMTP_ENABLED"] == "true":
            for key in ("SMTP_HOST", "SMTP_FROM", "SMTP_TO"):
                if not env[key]:
                    raise ValueError(f"email enabled without {key}")
            if not re.fullmatch(r"[a-zA-Z0-9.-]+:[0-9]+", env["SMTP_HOST"]):
                raise ValueError("SMTP_HOST must contain host:port")
            for key in ("SMTP_FROM", "SMTP_TO"):
                if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", env[key]):
                    raise ValueError(f"invalid email address: {key}")


def owned_path(root: Path, relative: str) -> Path:
    """Reject output paths outside the owning deployment."""
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("path leaves the owning deployment")
    return path


def render(root: Path, env: dict[str, str], spec: dict[str, Any]) -> None:
    """Render only declared files; preserve injected files with other names."""
    secret_root = owned_path(root, env["SECRET_ROOT"])
    for filename in spec["required_secrets"]:
        if not (secret_root / filename).is_file():
            raise ValueError(f"missing TLS or secret input: {filename}")
    if env.get("SMTP_ENABLED") == "true" and env["SMTP_USER"]:
        if not (secret_root / "smtp-password").read_text().strip():
            raise ValueError("SMTP_USER requires a nonempty smtp-password file")
    runtime = owned_path(root, env["RUNTIME_ROOT"])
    runtime.mkdir(parents=True, exist_ok=True)
    prefix = re.escape(spec["prefix"])

    def substitute(match: re.Match[str]) -> str:
        key = match.group(1)
        value: str | int = (
            int(env[key]) if key in spec.get("integers", []) else env[key]
        )
        return json.dumps(value)

    for item in spec["templates"]:
        if "when" in item and env[item["when"][0]] != item["when"][1]:
            continue
        source = owned_path(root, item["source"])
        target = owned_path(runtime, item["target"])
        target.parent.mkdir(parents=True, exist_ok=True)
        content = source.read_text()
        if source.suffix == ".json":
            content = re.sub(r'"(\$\{' + prefix + r'[A-Z_0-9]+\})"', r"\1", content)
        content = re.sub(r"\$\{" + prefix + r"([A-Z_0-9]+)\}", substitute, content)
        if source.suffix == ".json":
            json.loads(content)
        target.write_text(content)
        target.chmod(0o644)
    for relative in spec.get("empty_targets", []):
        path = owned_path(runtime, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            path.write_text("[]\n")
    LOG.info(json.dumps({"event": "configuration_prepared", "role": spec["role"]}))


def openssl(*args: str) -> None:
    """Run the installed operator tool without exposing private-key output."""
    subprocess.run(["openssl", *args], check=True, capture_output=True, text=True)


def authority(directory: Path, name: str) -> Path:
    """Create a missing local CA, never replace an existing private key."""
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    issuer = directory / name
    cert, key = issuer.with_suffix(".crt"), issuer.with_suffix(".key")
    if cert.exists() != key.exists():
        raise ValueError("incomplete existing local authority")
    if not key.exists():
        openssl(
            "req",
            "-x509",
            "-newkey",
            "rsa:3072",
            "-nodes",
            "-sha256",
            "-days",
            "365",
            "-subj",
            f"/CN=AELEV-local-{name}",
            "-addext",
            "basicConstraints=critical,CA:TRUE",
            "-addext",
            "keyUsage=critical,keyCertSign,cRLSign",
            "-addext",
            "subjectKeyIdentifier=hash",
            "-addext",
            "authorityKeyIdentifier=keyid:always",
            "-keyout",
            str(key),
            "-out",
            str(cert),
        )
        key.chmod(0o600)
    return issuer


def certificate(
    directory: Path, name: str, issuer: Path, usages: str, sans: list[str]
) -> None:
    """Issue one local certificate without putting keys in env or stdout."""
    key, request, extension = (
        directory / f"{name}.{suffix}" for suffix in ("key", "csr", "ext")
    )
    if key.exists() or key.with_suffix(".crt").exists():
        raise ValueError("certificate exists; preparation never overwrites keys")
    extension.write_text(
        "basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\n"
        + "subjectKeyIdentifier=hash\nauthorityKeyIdentifier=keyid,issuer\n"
        + f"extendedKeyUsage={usages}\n"
        + (f"subjectAltName={','.join(sans)}\n" if sans else "")
    )
    openssl(
        "req",
        "-new",
        "-newkey",
        "rsa:2048",
        "-nodes",
        "-keyout",
        str(key),
        "-out",
        str(request),
        "-subj",
        f"/CN={name}",
    )
    key.chmod(0o600)
    openssl(
        "x509",
        "-req",
        "-in",
        str(request),
        "-CA",
        str(issuer.with_suffix(".crt")),
        "-CAkey",
        str(issuer.with_suffix(".key")),
        "-set_serial",
        str(secrets.randbits(128)),
        "-days",
        "30",
        "-sha256",
        "-extfile",
        str(extension),
        "-out",
        str(directory / f"{name}.crt"),
    )
    request.unlink()
    extension.unlink()


def generate_tls(
    root: Path, env: dict[str, str], spec: dict[str, Any], issuer_dir: Path
) -> None:
    """Prepare only this owner's local TLS; production supplies approved PKI."""
    if not shutil.which("openssl"):
        raise ValueError("install OpenSSL as documented in README.md")
    directory = owned_path(root, env["SECRET_ROOT"])
    if directory.exists() and any(directory.iterdir()):
        raise ValueError(
            "secret directory is not empty; preparation never overwrites keys"
        )
    directory.mkdir(parents=True, exist_ok=True, mode=0o750)
    gid = int(env["SECRET_GID"])
    directory.chmod(0o750)
    os.chown(directory, -1, gid)
    internal = authority(issuer_dir, "internal-ca")
    publisher = authority(issuer_dir, "publisher-ca")
    shutil.copyfile(internal.with_suffix(".crt"), directory / "ca.crt")
    host = env["PUBLIC_HOST"]
    try:
        ipaddress.ip_address(host)
        public_san = f"IP:{host}"
    except ValueError:
        public_san = f"DNS:{host}"
    certificate(
        directory,
        "server",
        internal,
        "serverAuth",
        list(
            dict.fromkeys(
                [f"DNS:{spec['role']}", "DNS:localhost", "IP:127.0.0.1", public_san]
            )
        ),
    )
    certificate(directory, "client", internal, "clientAuth", [])
    for filename in spec.get("generated_secrets", []):
        (directory / filename).write_text(
            "" if filename == "smtp-password" else secrets.token_urlsafe(36)
        )
    if spec.get("publisher_ca"):
        shutil.copyfile(publisher.with_suffix(".crt"), directory / "publisher-ca.crt")
    if spec.get("telemetry_client"):
        certificate(directory, "telemetry", publisher, "clientAuth", [])
    if spec.get("trusted_ca"):
        trusted = directory / "trusted-ca"
        trusted.mkdir(mode=0o750)
        shutil.copyfile(internal.with_suffix(".crt"), trusted / "internal-ca.crt")
        openssl("rehash", str(trusted))
    for path in directory.rglob("*"):
        if path.is_file():
            os.chown(path, -1, gid)
            path.chmod(0o640)


def initialize(root: Path, owner: str, role: str, uid: int) -> None:
    """Initialize empty storage or verify its immutable existing owner marker."""
    marker = root / ".aelev-observability-owner"
    expected = {"project": owner, "role": role, "version": 1}
    if marker.exists():
        if json.loads(marker.read_text()) != expected:
            raise ValueError(f"foreign volume: {role}")
        return
    if any(root.iterdir()):
        raise ValueError(f"nonempty unmanaged volume: {role}")
    marker.write_text(json.dumps(expected) + "\n")
    os.chown(marker, uid, uid)
    os.chmod(marker, 0o600)
    os.chown(root, uid, uid)
    os.chmod(root, 0o700)


def main(root: Path) -> None:
    """Execute an explicit operation for exactly one owner-local deployment."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("init", "tls", "render"))
    parser.add_argument("--env-file", type=Path, default=root / ".env")
    parser.add_argument("--issuer-dir", type=Path, default=root / "secrets/issuer")
    args = parser.parse_args()
    spec = json.loads((root / "deployment.json").read_text())
    prefix = spec["prefix"]
    if args.action == "init":
        if args.env_file.exists():
            raise ValueError("env file exists; init never overwrites operator settings")
        content = (root / ".env.example").read_text()
        for suffix, value in (
            ("SECRET_GID", os.getgid()),
            ("UI_SECRET_GID", os.getgid()),
            ("UI_PROVISION_UID", os.getuid()),
        ):
            content = re.sub(
                r"(?m)^" + prefix + suffix + r"=.*$",
                f"{prefix}{suffix}={value}",
                content,
            )
        args.env_file.write_text(content)
        args.env_file.chmod(0o600)
        return
    env = read_env(args.env_file, prefix)
    validate(env, read_env(root / ".env.example", prefix), spec)
    if args.action == "tls":
        generate_tls(root, env, spec, args.issuer_dir.resolve())
    else:
        render(root, env, spec)
